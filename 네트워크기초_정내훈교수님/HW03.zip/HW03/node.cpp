#include <iostream>

#include "conn.h"

using namespace std;

volatile int send_state = 0;
char send_mess[200];

void do_node(char node_id)
{
	int a;
	bool end_node = false;

	cout << "Hello World, I am node " << node_id << ".\n";
	for (;;) {
		cout << "\nSelect One => 0.Quit,    1:Set CONN,     2:Reset CONN,     3:Read CONN : ";
		cin >> a;
		send_mess[0] = a;
		send_state = 1;
		while (2 != send_state);
		send_state = 0;
		if (0 == a) break;
	}
}

void check_conn(bool& my_conn)
{
	if (my_conn != g_conn.get()) {
		cout << "\n\ng_conn changed to";
		if (true == my_conn) cout << " False\n";
		else cout << " True\n";
		my_conn = !my_conn;
		cout << "Enter: ";
	}
}

void do_node_NIC(char node_id)
{
	bool my_conn = g_conn.get();
	for (;;) {
		while (1 != send_state)
			check_conn(my_conn);
		int a = send_mess[0];
		switch (a) {
		case 1: g_conn.set(true); my_conn = true; break;
		case 2: g_conn.set(false); my_conn = false;  break;
		case 3: cout << "g_conn is ";
			if (true == g_conn.get()) cout << "True\n";
			else cout << "False\n";
		}
		send_state = 2;
		if (0 == a) break;
	}

}